package aws.worshopdemo;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.PutItemOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.PutItemSpec;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class SaveStudentHandler implements RequestHandler<StudentRequest, StudentResponse>{
	
	private DynamoDB dynamoDb;
    private String DYNAMODB_TABLE_NAME = "Student";
    private Regions REGION = Regions.US_EAST_1;

	public StudentResponse handleRequest(StudentRequest studentRequest, Context context) {
		initDynamoDbClient();
		saveStudentRecord(studentRequest);
		StudentResponse response = new StudentResponse();
		response.setMessage("saved Succesfully");
		return response;
	}
	
	private void initDynamoDbClient() {
		AmazonDynamoDBClient client = new AmazonDynamoDBClient();
		client.setRegion(Region.getRegion(REGION));
		this.dynamoDb = new DynamoDB(client);
	}
	
	private PutItemOutcome saveStudentRecord(StudentRequest studentRequest) 
		      throws ConditionalCheckFailedException {
		String studentId = null;
		Table table = dynamoDb.getTable(DYNAMODB_TABLE_NAME);
		Item item = table.getItem("studentId" ,studentRequest.getFirstName()+ "-" +studentRequest.getLastName());
		if(item != null) {
			studentId = item.getString("studentId");
		}else {
			studentId = studentRequest.getFirstName()+ "-" +studentRequest.getLastName();
		}
		 return table
		          .putItem(
		            new PutItemSpec().withItem(new Item()
		              .withPrimaryKey("studentId" , studentId)
		              .withString("firstName", studentRequest.getFirstName())
		              .withString("lastName", studentRequest.getLastName())
		              .withString("department", studentRequest.getDepartment())));
		    }

}
